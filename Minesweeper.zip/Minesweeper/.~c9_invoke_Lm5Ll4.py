# Ivan Guillen
# CPTR 108
# May 3, 2019

# Minesweeper Project:

import mineFunctions

def checkSurrounding(x, y, key, rowSize, colSize):
    bombCounter = 0
    if (key[x - 1][y - 1] == '*'):
        bombCounter += 1
    if (key[x - 1][y] == '*'):
        bombCounter += 1
    if (key[x - 1][y + 1] == '*'):
        bombCounter += 1
    if (key[x][y - 1] == '*'):
        bombCounter += 1
    if (key[x][y + 1] == '*'):
        bombCounter += 1
    if (key[x + 1][y - 1] == '*'):
        bombCounter += 1
    if (key[x + 1][y] == '*'):
        bombCounter += 1
    if (key[x + 1][y + 1] == '*'):
        bombCounter += 1
    return bombCounter
        
x = 0
y = 0

print("Welcome to Minesweeper!")
print('\t')
print("1) Start New Game")
print("2) Load Saved Game")
print('\t')
option = input("What would you like to do: ")

if (option == 1):
    print('\t')
    row = input("How many rows would you like your table to have: ")
    col = input("How many columns would you like your table to have: ")
    table = [["] * col for i in range(row)]
    key = [['O'] * col for i in range(row)]
    mineFunctions.randNums(key)
    mineFunctions.assignBombs(key)

print('\n')

        
while (mineFunctions.gameOver(x, y, key) != True):
    mineFunctions.printTable(table)
    mineFunctions.printTable(key)
    x = input("Row: ") - 1
    y = input("Column: ") - 1
    table[x][y] = checkSurrounding(x, y, key, row, col)
    print('\t')
    if (mineFunctions.gameOver(x, y, key) == True):
        print("You have hit a bomb. GAME OVER")