#-*- coding: utf-8 -*-

# Ivan Guillen
# CPTR 108 - Art and Practice of Computer Science
# May 3, 2019

# main.py
# Minesweeper Project:

# Allows the use of end = in print functions
# You can end with spaces instead of endlines
from __future__ import print_function
# Mine Functions from mineFunctions.py
import mineFunctions
# Allows for exit() function
import sys

bombs = 0
remain = -1
turnCounter = 1

print("Welcome to Minesweeper!")
print('\t')
print("1) Start New Game")
print("2) Load Saved Game")
print('\t')

option = mineFunctions.errorCheck("What would you like to do: ", 0, 2)
    
if (option == 1):
    print('\t')
    print("Your table must have at least 8 rows and at most 20 rows")
    print("Your table must have at least 8 columns and at most 30 columns")
    print('\t')
    row = mineFunctions.errorCheck("How many rows would you like your table to have: ", 7, 20) # Size requirements can be changed
    col = mineFunctions.errorCheck("How many columns would you like your table to have: ", 7, 30) # Size requirements can be changed
    table = [['o'] * col for i in range(row)] # Creates 2d array that user sees. 
    key = [['O'] * col for i in range(row)] # Creates 2d array that holds bombs. Used as key for checking win or lose status.
    print('\t')
    mineFunctions.randNums(key) # Creates game status key
    mineFunctions.assignBombs(key) # Creates game status key
    mineFunctions.printTable(table, col)

if (option == 2):
    print('\t')
    sys.exit("Unfortunately, this feature is not available yet. Sorry for the inconvenience.")
    
print('\t')

bombs = mineFunctions.numberOfBombs(key) # Counts number of bombs

while True: # Loops until user hits bomb or wins
    print("Turn #", end = '')
    print(turnCounter)
    print('\t')
    print("1) Select block")
    print("2) Place flag")
    print("3) Save Game to File and Exit")
    print("4) End Game Without Saving")
    print('\t')
    
    option2 = mineFunctions.errorCheck("What would you like to do: ", 0, 4)
    
    if (option2 == 1):
        print('\t')
        counter = 0
        mineFunctions.printTable(table, col)
        x = mineFunctions.errorCheck("Row #: ", 0, row) - 1
        y = mineFunctions.errorCheck("Column #: ", 0, col) - 1
        mineFunctions.reveal(x, y, table, key, row, col)
        while (counter < 20): # Iterates through table multiple times to reveal adjacent squares
            if (table[x][y] == 0):
                for i in range(len(table)):
                    for j in range(len(table[i])):
                        if (table[i][j] == 0):
                            mineFunctions.revealNeighbors(i, j, table, key, row, col)
            counter += 1
        remain = mineFunctions.remainingSpaces(table)
        print('\t')
        if (mineFunctions.gameOver(x, y, key) == True): # Checks if user hit bomb
            key[x][y] = 'B'
            mineFunctions.printTable(key, col)
            print('\t')
            print("You have hit a bomb. Game over.")
            break
        elif (bombs == remain): # Checks if user has won by comparing number of bombs with number of remaining uncovered spaces
            print('\t')
            mineFunctions.printTable(table, col)
            mineFunctions.printTable(key, col)
            sys.exit("Congratulations! You won!")
        else:
            mineFunctions.printTable(table, col)
            print('\t')
            
    if (option2 == 2): # Allows user to place a flag. 
        print('\t')
        mineFunctions.printTable(table, col)
        x = mineFunctions.errorCheck("Row #: ", 0, row) - 1
        y = mineFunctions.errorCheck("Column #: ", 0, col) - 1
        table[x][y] = 'F'
        print('\t')
        mineFunctions.printTable(table, col)

    if (option2 == 3): # Allows user to write table to test file
        print('\t')
        mineFunctions.writeToFile(table)
        print('\t')
        print("Goodbye!")
        break
        
    if (option2 == 4): # Exits program
        print('\t')
        print("Goodbye!")
        break
    turnCounter += 1